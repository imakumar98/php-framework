<?php 

    class Obj{



        public function __construct(){

        }

    }


    $obj1 = new Obj();




?>