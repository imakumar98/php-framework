<?php

    DEFINE('DB_HOST','localhost');
    DEFINE('DB_USER','henrqfaw_ashwani');
    DEFINE('DB_PASS','ashwanikum12');
    DEFINE('DB_NAME','henrqfaw_framework');





?>